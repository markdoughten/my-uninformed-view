# [hopeinsource.com](https://hopeinsource.com)

## Run

```sh
yarn
yarn dev
open https://localhost:8000
```

## Updating pages

> https://github.com/hzoo/hopeinsource.com/tree/master/src/pages

